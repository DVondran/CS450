#include "sd_thread.h"	

STDDEV_RESULT* calcSdSerial(double *A, long N);

THRESH_RESULT *findThreshValuesSerial(double *A, long N, double T);
