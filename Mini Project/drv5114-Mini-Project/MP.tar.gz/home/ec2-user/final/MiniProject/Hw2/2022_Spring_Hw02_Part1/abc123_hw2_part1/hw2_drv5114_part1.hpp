

void myfunc(double *s, double *mat, int *v, int length);
