/**
 * This is a simple header file that declares the function in the library.
 */

void matrix_mult(double *A, double *B, double *C, int N);
